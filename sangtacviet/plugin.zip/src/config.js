let BASE_URL = "https://sangtacviet.app";
try
{
    if (CONFIG_URL)
    {
        BASE_URL = CONFIG_URL;
    }
}
catch (e)
{
}
